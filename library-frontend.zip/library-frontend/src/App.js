// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import BooksPage from './pages/BooksPage';
import MembersPage from './pages/MembersPage';
import TransactionsPage from './pages/TransactionsPage';
import { Navbar, Nav, Container } from 'react-bootstrap';

function App() {
    return (
        <Router>
            <div>
                <Navbar bg="light" expand="lg">
                    <Container>
                        <Navbar.Brand href="/">Library Management</Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                            <Nav className="me-auto">
                                <Nav.Link href="/books">Books</Nav.Link>
                                <Nav.Link href="/members">Members</Nav.Link>
                                <Nav.Link href="/transactions">Transactions</Nav.Link>
                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
                <Container>
                    <Routes>
                        <Route path="/books" element={<BooksPage />} />
                        <Route path="/members" element={<MembersPage />} />
                        <Route path="/transactions" element={<TransactionsPage />} />
                        <Route path="/" element={<BooksPage />} />
                    </Routes>
                </Container>
            </div>
        </Router>
    );
}

export default App;
