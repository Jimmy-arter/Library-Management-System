// src/services/api.js

import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

export const getBooks = async () => {
    const response = await axios.get(`${API_URL}/books/`);
    return response.data;
};

export const createBook = async (book) => {
    const response = await axios.post(`${API_URL}/books/`, book);
    return response.data;
};

export const getMembers = async () => {
    const response = await axios.get(`${API_URL}/members/`);
    return response.data;
};

export const createMember = async (member) => {
    const response = await axios.post(`${API_URL}/members/`, member);
    return response.data;
};

export const getTransactions = async () => {
    const response = await axios.get(`${API_URL}/transactions/`);
    return response.data;
};

export const issueBook = async (transaction) => {
    const response = await axios.post(`${API_URL}/transactions/issue_book/`, transaction);
    return response.data;
};

export const returnBook = async (transactionId, returnDate) => {
    const response = await axios.post(`${API_URL}/transactions/${transactionId}/return_book/`, returnDate);
    return response.data;
};

export const getTransactionsByMemberId = async (memberId) => {
    const response = await axios.get(`${API_URL}/transactions/member/${memberId}/`);
    return response.data;
};