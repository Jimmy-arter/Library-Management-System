import React, { useState } from 'react';
import { createMember } from '../services/api';

const MemberForm = () => {
    const [name, setName] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await createMember({ name, outstanding_debt: 0 });
            setName('');
        } catch (error) {
            alert('Failed to add member');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
            />
            <button type="submit">Add Member</button>
        </form>
    );
};

export default MemberForm;
