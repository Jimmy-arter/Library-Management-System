import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';

const AddMemberPage = () => {
const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
};

return (
    <Container>
    <Row className="justify-content-md-center">
        <Col md={6}>
        <h1 className="mb-4">Add New Member</h1>
        <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formName">
            <Form.Label>Name</Form.Label>
            <Form.Control type="text" placeholder="Enter member name" />
            </Form.Group>

            <Form.Group controlId="formOutstandingDebt">
            <Form.Label>Outstanding Debt</Form.Label>
            <Form.Control type="number" placeholder="Enter outstanding debt" />
            </Form.Group>

            <Button variant="primary" type="submit" className="mt-3">
            Add Member
            </Button>
        </Form>
        </Col>
    </Row>
    </Container>
);
};

export default AddMemberPage;