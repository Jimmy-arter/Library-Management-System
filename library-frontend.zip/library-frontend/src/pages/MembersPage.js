// src/pages/MembersPage.js
import React from 'react';
import useFetch from '../hooks/useFetch';
import { Table, Container, Row, Col, Button, Spinner, Alert } from 'react-bootstrap';

const MembersPage = () => {
    const { data: members, loading, error } = useFetch('http://localhost:8000/api/members/');

    return (
        <Container>
            <Row>
                <Col>
                    <h1 className="my-4">Library Members</h1>
                    <Button variant="primary" href="/add-member" className="mb-3">
                        Add New Member
                    </Button>
                    {loading && <Spinner animation="border" />}
                    {error && <Alert variant="danger">Failed to fetch members</Alert>}
                    {!loading && !error && (
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Outstanding Debt (KES)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {members.map((member, index) => (
                                    <tr key={member.id}>
                                        <td>{index + 1}</td>
                                        <td>{member.name}</td>
                                        <td>{member.outstanding_debt}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    )}
                </Col>
            </Row>
        </Container>
    );
};

export default MembersPage;
