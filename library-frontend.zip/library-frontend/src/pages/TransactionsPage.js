// src/pages/TransactionsPage.js

import React, { useState, useEffect } from 'react';
import { Table, Button, Form, Alert } from 'react-bootstrap';
import { getTransactions, issueBook, returnBook } from '../services/api';

const TransactionsPage = () => {
    const [transactions, setTransactions] = useState([]);
    const [memberId, setMemberId] = useState('');
    const [bookId, setBookId] = useState('');
    const [returnDate, setReturnDate] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        fetchTransactions();
    }, []);

    const fetchTransactions = async () => {
        const data = await getTransactions();
        setTransactions(data);
    };

    const handleIssueBook = async (e) => {
        e.preventDefault();
        try {
            await issueBook({ member_id: memberId, book_id: bookId });
            setMemberId('');
            setBookId('');
            fetchTransactions();
        } catch (error) {
            setErrorMessage('Failed to issue book');
        }
    };

    const handleReturnBook = async (transactionId) => {
        try {
            await returnBook(transactionId, { return_date: returnDate });
            setReturnDate('');
            fetchTransactions();
        } catch (error) {
            setErrorMessage('Failed to return book');
        }
    };

    return (
        <div>
            <h2>Transactions</h2>
            {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
            <Form onSubmit={handleIssueBook}>
                <Form.Group>
                    <Form.Label>Member ID</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter member ID"
                        value={memberId}
                        onChange={(e) => setMemberId(e.target.value)}
                        required
                    />
                </Form.Group>
                <Form.Group>
                    <Form.Label>Book ID</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter book ID"
                        value={bookId}
                        onChange={(e) => setBookId(e.target.value)}
                        required
                    />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Issue Book
                </Button>
            </Form>
            <Form className="mt-4">
                <Form.Group>
                    <Form.Label>Return Date</Form.Label>
                    <Form.Control
                        type="date"
                        placeholder="Enter return date"
                        value={returnDate}
                        onChange={(e) => setReturnDate(e.target.value)}
                        required
                    />
                </Form.Group>
            </Form>
            <Table striped bordered hover className="mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Member ID</th>
                        <th>Book ID</th>
                        <th>Issue Date</th>
                        <th>Return Date</th>
                        <th>Rent Fee</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map((transaction, index) => (
                        <tr key={transaction.id}>
                            <td>{index + 1}</td>
                            <td>{transaction.member}</td>
                            <td>{transaction.book}</td>
                            <td>{transaction.issue_date}</td>
                            <td>{transaction.return_date || 'Not returned'}</td>
                            <td>{transaction.fee || 0}</td>
                            <td>
                                {!transaction.return_date && (
                                    <Button
                                        variant="success"
                                        onClick={() => handleReturnBook(transaction.id)}
                                    >
                                        Return Book
                                    </Button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default TransactionsPage;
